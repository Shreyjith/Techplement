import secrets
import string
import time
from datetime import datetime, timedelta
import os
import platform
from pathlib import Path
import getpass
import tempfile
import sqlite3
import bcrypt
from cryptography.fernet import Fernet
import unittest


class SecurityBestPractices:
    def __init__(self, db_cursor, cipher_suite):
        self.cursor = db_cursor
        self.cipher_suite = cipher_suite

    def hash_password(self, password):
        salt = bcrypt.gensalt()
        return bcrypt.hashpw(password.encode(), salt)

    def check_password(self, hashed, user_password):
        return bcrypt.checkpw(user_password.encode(), hashed)

    def generate_password(self, length=12):
        characters = string.ascii_letters + string.digits + string.punctuation
        return ''.join(secrets.choice(characters) for _ in range(length))

    def password_strength(self, password):
        length_criteria = len(password) >= 8
        digit_criteria = any(char.isdigit() for char in password)
        upper_criteria = any(char.isupper() for char in password)
        lower_criteria = any(char.islower() for char in password)
        special_criteria = any(char in string.punctuation for char in password)

        if all([length_criteria, digit_criteria, upper_criteria, lower_criteria, special_criteria]):
            return "Strong"
        elif any([length_criteria, digit_criteria, upper_criteria, lower_criteria, special_criteria]):
            return "Medium"
        else:
            return "Weak"

    def session_timeout(self, last_login):
        return datetime.now() > last_login + timedelta(minutes=30)

    def password_reuse_detection(self, user_id, new_password):
        self.cursor.execute("SELECT password FROM passwords WHERE user_id=?", (user_id,))
        for row in self.cursor.fetchall():
            decrypted_password = self.cipher_suite.decrypt(row[0]).decode()
            if new_password == decrypted_password:
                return True
        return False


class CrossPlatformCompatibility:
    def __init__(self):
        self.user_home_dir = Path.home()
        self.os_type = platform.system()
        self.temp_dir = Path(tempfile.gettempdir())
    
    def get_user_home_directory(self):
        return self.user_home_dir

    def get_os_type(self):
        return self.os_type

    def create_temp_file(self, content):
        temp_file_path = self.temp_dir / "tempfile.txt"
        with open(temp_file_path, 'w') as temp_file:
            temp_file.write(content)
        return temp_file_path

    def get_environment_variable(self, var_name):
        return os.getenv(var_name)

    def set_environment_variable(self, var_name, value):
        os.environ[var_name] = value

    def get_username(self):
        return getpass.getuser()

    def os_specific_functionality(self):
        if self.os_type == "Windows":
            return self._windows_specific_function()
        elif self.os_type == "Darwin":
            return self._mac_specific_function()
        elif self.os_type == "Linux":
            return self._linux_specific_function()
        else:
            return "Unsupported OS"

    def _windows_specific_function(self):
        return "Performing Windows-specific operations."

    def _mac_specific_function(self):
        return "Performing macOS-specific operations."

    def _linux_specific_function(self):
        return "Performing Linux-specific operations."


class PasswordManager:
    def __init__(self, db_name='passwords.db'):
        self.key = Fernet.generate_key()
        self.cipher_suite = Fernet(self.key)
        self.conn = sqlite3.connect(db_name)
        self.cursor = self.conn.cursor()
        self.sbp = SecurityBestPractices(self.cursor, self.cipher_suite)
        self.cpc = CrossPlatformCompatibility()
        self.create_tables()

    def create_tables(self):
        self.cursor.execute('''CREATE TABLE IF NOT EXISTS users (
                               id INTEGER PRIMARY KEY, 
                               username TEXT UNIQUE, 
                               password TEXT, 
                               last_login TIMESTAMP)''')
        self.cursor.execute('''CREATE TABLE IF NOT EXISTS passwords (
                               id INTEGER PRIMARY KEY, 
                               user_id INTEGER, 
                               service TEXT, 
                               username TEXT, 
                               password TEXT, 
                               created_at TIMESTAMP, 
                               FOREIGN KEY(user_id) REFERENCES users(id))''')
        self.conn.commit()

    def add_user(self, username, password):
        hashed_password = self.sbp.hash_password(password)
        try:
            self.cursor.execute("INSERT INTO users (username, password, last_login) VALUES (?, ?, ?)",
                                (username, hashed_password, datetime.now()))
            self.conn.commit()
        except sqlite3.IntegrityError:
            print("Username already exists.")

    def authenticate_user(self, username, password):
        self.cursor.execute("SELECT id, password, last_login FROM users WHERE username=?", (username,))
        user = self.cursor.fetchone()
        if user and self.sbp.check_password(user[1], password):
            if self.sbp.session_timeout(user[2]):
                print("Session expired. Please login again.")
                return False
            else:
                self.cursor.execute("UPDATE users SET last_login=? WHERE username=?", (datetime.now(), username))
                self.conn.commit()
                return user[0]
        else:
            print("Invalid credentials.")
            return False

    def add_password(self, user_id, service, username, password):
        encrypted_password = self.cipher_suite.encrypt(password.encode())
        self.cursor.execute("INSERT INTO passwords (user_id, service, username, password, created_at) VALUES (?, ?, ?, ?, ?)",
                            (user_id, service, username, encrypted_password, datetime.now()))
        self.conn.commit()

    def retrieve_password(self, user_id, service):
        self.cursor.execute("SELECT username, password FROM passwords WHERE user_id=? AND service=?", (user_id, service))
        row = self.cursor.fetchone()
        if row:
            decrypted_password = self.cipher_suite.decrypt(row[1]).decode()
            return row[0], decrypted_password
        else:
            return None, None

    def main(self):
        print("Welcome to the Password Manager")

        print(f"User Home Directory: {self.cpc.get_user_home_directory()}")
        print(f"Operating System: {self.cpc.get_os_type()}")
        print(f"Username: {self.cpc.get_username()}")

        temp_file_path = self.cpc.create_temp_file("This is a temporary file for testing cross-platform compatibility.")
        print(f"Temporary file created at: {temp_file_path}")

        self.cpc.set_environment_variable("TEST_VAR", "test_value")
        print(f"Environment Variable TEST_VAR: {self.cpc.get_environment_variable('TEST_VAR')}")

        print(self.cpc.os_specific_functionality())

        while True:
            print("\n1. Register")
            print("2. Login")
            print("3. Exit")
            choice = input("Enter your choice: ")

            if choice == '1':
                username = input("Enter a new username: ")
                password = getpass.getpass("Enter a new password: ")
                self.add_user(username, password)
                print("User registered successfully!")
            elif choice == '2':
                username = input("Enter your username: ")
                password = getpass.getpass("Enter your password: ")
                user_id = self.authenticate_user(username, password)
                if user_id:
                    while True:
                        print("\n1. Add Password")
                        print("2. Retrieve Password")
                        print("3. Generate Password")
                        print("4. Logout")
                        sub_choice = input("Enter your choice: ")

                        if sub_choice == '1':
                            service = input("Enter the service name: ")
                            service_username = input("Enter the service username: ")
                            service_password = getpass.getpass("Enter the service password: ")
                            strength = self.sbp.password_strength(service_password)
                            print(f"Password strength: {strength}")
                            if self.sbp.password_reuse_detection(user_id, service_password):
                                print("Password reuse detected! Use a different password.")
                            else:
                                self.add_password(user_id, service, service_username, service_password)
                                print("Password added successfully!")
                        elif sub_choice == '2':
                            service = input("Enter the service name: ")
                            service_username, service_password = self.retrieve_password(user_id, service)
                            if service_username:
                                print(f"Username: {service_username}")
                                print(f"Password: {service_password}")
                            else:
                                print("Service not found.")
                        elif sub_choice == '3':
                            length = int(input("Enter the desired password length: "))
                            generated_password = self.sbp.generate_password(length)
                            strength = self.sbp.password_strength(generated_password)
                            print(f"Generated Password: {generated_password}")
                            print(f"Password strength: {strength}")
                        elif sub_choice == '4':
                            break
                        else:
                            print("Invalid choice. Please try again.")
            elif choice == '3':
                break
            else:
                print("Invalid choice. Please try again.")


# Testing and Quality Assurance
class TestSecurityBestPractices(unittest.TestCase):

    @classmethod
    def setUpClass(cls):
        cls.key = Fernet.generate_key()
        cls.cipher_suite = Fernet(cls.key)
        cls.conn = sqlite3.connect(':memory:')  # Use in-memory database for testing
        cls.cursor = cls.conn.cursor()
        cls.cursor.execute('''CREATE TABLE IF NOT EXISTS passwords (
                               id INTEGER PRIMARY KEY, 
                               user_id INTEGER, 
                               service TEXT, 
                               username TEXT, 
                               password TEXT, 
                               created_at TIMESTAMP)''')
        cls.conn.commit()
        cls.sbp = SecurityBestPractices(cls.cursor, cls.cipher_suite)

    def test_generate_password(self):
        password = self.sbp.generate_password(12)
        self.assertEqual(len(password), 12)

    def test_password_strength(self):
        weak_password = "abc"
        medium_password = "abc123"
        strong_password = "Abc123@#"
        self.assertEqual(self.sbp.password_strength(weak_password), "Weak")
        self.assertEqual(self.sbp.password_strength(medium_password), "Medium")
        self.assertEqual(self.sbp.password_strength(strong_password), "Strong")

    def test_hash_password(self):
        password = "mypassword"
        hashed = self.sbp.hash_password(password)
        self.assertTrue(self.sbp.check_password(hashed, password))

    def test_session_timeout(self):
        last_login = datetime.now() - timedelta(minutes=31)
        self.assertTrue(self.sbp.session_timeout(last_login))
        last_login = datetime.now() - timedelta(minutes=29)
        self.assertFalse(self.sbp.session_timeout(last_login))

    def test_password_reuse_detection(self):
        self.sbp.cursor.execute("INSERT INTO passwords (user_id, service, username, password, created_at) VALUES (?, ?, ?, ?, ?)",
                                (1, "service_reuse", "user_reuse", self.sbp.cipher_suite.encrypt("Reuse@123".encode()), datetime.now()))
        self.conn.commit()
        self.assertTrue(self.sbp.password_reuse_detection(1, "Reuse@123"))
        self.assertFalse(self.sbp.password_reuse_detection(1, "Different@123"))


class TestCrossPlatformCompatibility(unittest.TestCase):

    @classmethod
    def setUpClass(cls):
        cls.cpc = CrossPlatformCompatibility()

    def test_user_home_directory(self):
        home_dir = self.cpc.get_user_home_directory()
        self.assertTrue(home_dir.exists())

    def test_os_type(self):
        os_type = self.cpc.get_os_type()
        self.assertIn(os_type, ["Windows", "Darwin", "Linux"])

    def test_create_temp_file(self):
        content = "Temporary file content."
        temp_file_path = self.cpc.create_temp_file(content)
        self.assertTrue(temp_file_path.exists())
        with open(temp_file_path, 'r') as temp_file:
            self.assertEqual(temp_file.read(), content)

    def test_environment_variable(self):
        self.cpc.set_environment_variable("TEST_VAR", "test_value")
        self.assertEqual(self.cpc.get_environment_variable("TEST_VAR"), "test_value")

    def test_get_username(self):
        username = self.cpc.get_username()
        self.assertIsNotNone(username)

    def test_os_specific_functionality(self):
        result = self.cpc.os_specific_functionality()
        self.assertIsNotNone(result)


if __name__ == '__main__':
    unittest.main(exit=False)

    pm = PasswordManager()
    pm.main()
