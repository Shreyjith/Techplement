import kivy
from kivy.app import App
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.label import Label
from kivy.uix.button import Button
from kivy.uix.textinput import TextInput
from kivy.uix.popup import Popup
from kivy.uix.screenmanager import ScreenManager, Screen
import sqlite3
from cryptography.fernet import Fernet
import bcrypt
from datetime import datetime

# Function to generate and save the encryption key
def generate_key():
    key = Fernet.generate_key()
    with open("secret.key", "wb") as key_file:
        key_file.write(key)

# Function to load the encryption key
def load_key():
    return open("secret.key", "rb").read()

# Generate the key if it does not exist
try:
    key = load_key()
except FileNotFoundError:
    generate_key()
    key = load_key()

cipher_suite = Fernet(key)

# Database setup for password manager
conn = sqlite3.connect('password_manager.db')
c = conn.cursor()

# Database setup for account management
account_conn = sqlite3.connect('Account.db')
account_c = account_conn.cursor()

# Create tables if they do not exist
c.execute('''
CREATE TABLE IF NOT EXISTS passwords (
    id INTEGER PRIMARY KEY,
    site TEXT,
    username TEXT,
    email TEXT,
    password TEXT,
    category TEXT,
    tags TEXT,
    last_updated TEXT
)
''')
conn.commit()

account_c.execute('''
CREATE TABLE IF NOT EXISTS users (
    id INTEGER PRIMARY KEY,
    username TEXT UNIQUE,
    email TEXT,
    password TEXT
)
''')
account_conn.commit()

# Function to encrypt data
def encrypt_data(data):
    encrypted_data = cipher_suite.encrypt(data.encode())
    return encrypted_data.decode('utf-8')

# Function to decrypt data
def decrypt_data(encrypted_data):
    decrypted_data = cipher_suite.decrypt(encrypted_data.encode('utf-8'))
    return decrypted_data.decode('utf-8')

class LoginScreen(Screen):
    def __init__(self, **kwargs):
        super(LoginScreen, self).__init__(**kwargs)
        layout = BoxLayout(orientation='vertical', padding=10, spacing=10)
        layout.add_widget(Label(text="Password Manager"))
        self.username_input = TextInput(hint_text="Username", multiline=False)
        layout.add_widget(self.username_input)
        self.password_input = TextInput(hint_text="Password", password=True, multiline=False)
        layout.add_widget(self.password_input)
        layout.add_widget(Button(text="Login", on_press=self.login))
        layout.add_widget(Button(text="Register", on_press=self.register))
        self.add_widget(layout)

    def login(self, instance):
        username = self.username_input.text
        password = self.password_input.text
        if self.authenticate_user(username, password):
            self.manager.current = 'main'
        else:
            self.show_popup("Invalid login credentials")

    def register(self, instance):
        self.manager.current = 'register'

    def authenticate_user(self, username, password):
        account_c.execute("SELECT password FROM users WHERE username = ?", (username,))
        result = account_c.fetchone()
        if result and bcrypt.checkpw(password.encode(), result[0]):
            return True
        return False

    def show_popup(self, message):
        popup = Popup(title='Error', content=Label(text=message), size_hint=(None, None), size=(400, 200))
        popup.open()

class RegisterScreen(Screen):
    def __init__(self, **kwargs):
        super(RegisterScreen, self).__init__(**kwargs)
        layout = BoxLayout(orientation='vertical', padding=10, spacing=10)
        layout.add_widget(Label(text="Register"))
        self.username_input = TextInput(hint_text="Username", multiline=False)
        layout.add_widget(self.username_input)
        self.email_input = TextInput(hint_text="Email", multiline=False)
        layout.add_widget(self.email_input)
        self.password_input = TextInput(hint_text="Password", password=True, multiline=False)
        layout.add_widget(self.password_input)
        layout.add_widget(Button(text="Register", on_press=self.register))
        layout.add_widget(Button(text="Back to Login", on_press=self.go_back))
        self.add_widget(layout)

    def register(self, instance):
        username = self.username_input.text
        email = self.email_input.text
        password = self.password_input.text
        if self.create_user(username, email, password):
            self.manager.current = 'login'
        else:
            self.show_popup("Registration failed. Username may already be taken.")

    def create_user(self, username, email, password):
        hashed = bcrypt.hashpw(password.encode(), bcrypt.gensalt()).decode()
        try:
            account_c.execute("INSERT INTO users (username, email, password) VALUES (?, ?, ?)", (username, email, hashed))
            account_conn.commit()
            return True
        except sqlite3.IntegrityError:
            return False

    def go_back(self, instance):
        self.manager.current = 'login'

    def show_popup(self, message):
        popup = Popup(title='Error', content=Label(text=message), size_hint=(None, None), size=(400, 200))
        popup.open()

class MainScreen(Screen):
    def __init__(self, **kwargs):
        super(MainScreen, self).__init__(**kwargs)
        layout = BoxLayout(orientation='vertical', padding=10, spacing=10)
        layout.add_widget(Label(text="Password Manager"))
        layout.add_widget(Button(text="Add Password", on_press=self.add_password))
        layout.add_widget(Button(text="View Passwords", on_press=self.view_passwords))
        layout.add_widget(Button(text="Logout", on_press=self.logout))
        self.add_widget(layout)

    def add_password(self, instance):
        self.manager.current = 'add_password'

    def view_passwords(self, instance):
        self.manager.current = 'view_passwords'

    def logout(self, instance):
        self.manager.current = 'login'

class AddPasswordScreen(Screen):
    def __init__(self, **kwargs):
        super(AddPasswordScreen, self).__init__(**kwargs)
        layout = BoxLayout(orientation='vertical', padding=10, spacing=10)
        layout.add_widget(Label(text="Add Password"))
        self.site_input = TextInput(hint_text="Site", multiline=False)
        layout.add_widget(self.site_input)
        self.username_input = TextInput(hint_text="Username", multiline=False)
        layout.add_widget(self.username_input)
        self.email_input = TextInput(hint_text="Email", multiline=False)
        layout.add_widget(self.email_input)
        self.password_input = TextInput(hint_text="Password", multiline=False)
        layout.add_widget(self.password_input)
        self.category_input = TextInput(hint_text="Category", multiline=False)
        layout.add_widget(self.category_input)
        self.tags_input = TextInput(hint_text="Tags", multiline=False)
        layout.add_widget(self.tags_input)
        layout.add_widget(Button(text="Save", on_press=self.save_password))
        layout.add_widget(Button(text="Back", on_press=self.go_back))
        self.add_widget(layout)

    def save_password(self, instance):
        site = self.site_input.text
        username = self.username_input.text
        email = self.email_input.text
        password = encrypt_data(self.password_input.text)
        category = self.category_input.text
        tags = self.tags_input.text
        last_updated = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        c.execute("INSERT INTO passwords (site, username, email, password, category, tags, last_updated) VALUES (?, ?, ?, ?, ?, ?, ?)", (site, username, email, password, category, tags, last_updated))
        conn.commit()
        self.show_popup("Password saved successfully!")

    def go_back(self, instance):
        self.manager.current = 'main'

    def show_popup(self, message):
        popup = Popup(title='Success', content=Label(text=message), size_hint=(None, None), size=(400, 200))
        popup.open()

class ViewPasswordsScreen(Screen):
    def __init__(self, **kwargs):
        super(ViewPasswordsScreen, self).__init__(**kwargs)
        layout = BoxLayout(orientation='vertical', padding=10, spacing=10)
        layout.add_widget(Label(text="View Passwords"))
        self.passwords_table = BoxLayout(orientation='vertical')
        layout.add_widget(self.passwords_table)
        layout.add_widget(Button(text="Reload", on_press=self.load_passwords))
        layout.add_widget(Button(text="Back", on_press=self.go_back))
        self.add_widget(layout)
        self.load_passwords()

    def load_passwords(self, instance=None):
        self.passwords_table.clear_widgets()
        c.execute("SELECT site, username, email, password, category, tags, last_updated FROM passwords")
        for row in c.fetchall():
            decrypted_password = decrypt_data(row[3])
            password_info = f"Site: {row[0]}, Username: {row[1]}, Email: {row[2]}, Password: {decrypted_password}, Category: {row[4]}, Tags: {row[5]}, Last Updated: {row[6]}"
            self.passwords_table.add_widget(Label(text=password_info))

    def go_back(self, instance):
        self.manager.current = 'main'

class PasswordManagerApp(App):
    def build(self):
        sm = ScreenManager()
        sm.add_widget(LoginScreen(name='login'))
        sm.add_widget(RegisterScreen(name='register'))
        sm.add_widget(MainScreen(name='main'))
        sm.add_widget(AddPasswordScreen(name='add_password'))
        sm.add_widget(ViewPasswordsScreen(name='view_passwords'))
        return sm

if __name__ == "__main__":
    PasswordManagerApp().run()
