import bcrypt
import json
from datetime import datetime
from cryptography.fernet import Fernet

# Generate a key for encryption
key = Fernet.generate_key()
cipher_suite = Fernet(key)

# Function to encrypt sensitive data
def encrypt_data(data):
    encrypted_data = cipher_suite.encrypt(data.encode())
    return encrypted_data

# Function to decrypt sensitive data
def decrypt_data(encrypted_data):
    decrypted_data = cipher_suite.decrypt(encrypted_data).decode()
    return decrypted_data

# Function to hash a password
def hash_password(password):
    hashed = bcrypt.hashpw(password.encode(), bcrypt.gensalt())
    return hashed

# Function to verify a password
def verify_password(password, hashed):
    return bcrypt.checkpw(password.encode(), hashed)

# User consent log
consent_log = []

# Function to log user consent
def log_user_consent(user_id, consent):
    consent_entry = {
        "user_id": user_id,
        "consent": consent,
        "timestamp": datetime.utcnow().isoformat()
    }
    consent_log.append(consent_entry)

# Function to retrieve user data
def get_user_data(user_id):
    # This function should retrieve user data from your database
    # For example purposes, returning a sample data
    return {"user_id": user_id, "data": "user_data"}

# Function to delete user data
def delete_user_data(user_id):
    # This function should delete user data from your database
    # For example purposes, printing a message
    print(f"Data for user_id {user_id} has been deleted")

# Function to handle user data access request
def handle_data_access_request(user_id):
    user_data = get_user_data(user_id)
    return user_data

# Function to handle user data deletion request
def handle_data_deletion_request(user_id):
    delete_user_data(user_id)
    return {"status": "success", "message": f"Data for user_id {user_id} has been deleted"}

# Example privacy policy content
privacy_policy = """
Privacy Policy:
Your data is encrypted and securely stored. We comply with GDPR and CCPA regulations.
You have the right to access, modify, and delete your data. Contact us for any privacy-related concerns.
"""

# Function to display privacy policy
def display_privacy_policy():
    print(privacy_policy)

# Example usage
if __name__ == "__main__":
    try:
        print("Starting script...")

        # Prompt for user input for encryption and decryption
        sensitive_data = input("Enter the data you want to encrypt: ")
        password = input("Enter a password to hash: ")
        user_id = int(input("Enter your user ID: "))

        # Encrypt data
        print("Encrypting data...")
        encrypted_data = encrypt_data(sensitive_data)
        print(f"Encrypted: {encrypted_data}")

        # Prompt for decryption
        decrypt_request = input("Do you want to see the decrypted data? (yes/no): ").strip().lower()
        if decrypt_request == "yes":
            print("Decrypting data...")
            decrypted_data = decrypt_data(encrypted_data)
            print(f"Decrypted: {decrypted_data}")

        # Hash and verify password
        print("Hashing password...")
        hashed_password = hash_password(password)
        print(f"Password is correct: {verify_password(password, hashed_password)}")
        print(f"Password is incorrect: {verify_password('wrong_password', hashed_password)}")

        # Log user consent
        print("Logging user consent...")
        log_user_consent(user_id, "agree")
        print(json.dumps(consent_log, indent=4))

        # Handle data access request
        print("Handling data access request...")
        access_request = handle_data_access_request(user_id)
        print(access_request)

        # Prompt for deletion request
        delete_request = input("Do you want to delete the user data? (yes/no): ").strip().lower()
        if delete_request == "yes":
            print("Handling data deletion request...")
            deletion_request = handle_data_deletion_request(user_id)
            print(deletion_request)

        # Display privacy policy
        print("Displaying privacy policy...")
        display_privacy_policy()

        print("Script finished.")
    except Exception as e:
        print(f"An error occurred: {e}")
