import bcrypt
import getpass
import random
import smtplib
import json
import string
from cryptography.fernet import Fernet
import secrets

key = Fernet.generate_key()
cipher_suite = Fernet(key)

users = {}
passwords = {}
emails = {}

def load_users():
    global users
    try:
        with open('users.json', 'r') as file:
            users = {k: v.encode() for k, v in json.load(file).items()}
    except FileNotFoundError:
        users = {}

def load_passwords():
    global passwords
    try:
        with open('passwords.json', 'r') as file:
            passwords.update(json.load(file))
    except FileNotFoundError:
        passwords = {}

def load_emails():
    global emails
    try:
        with open('emails.json', 'r') as file:
            emails.update(json.load(file))
    except FileNotFoundError:
        emails = {}

def save_users():
    with open('users.json', 'w') as file:
        json.dump({k: v.decode() for k, v in users.items()}, file)

def save_passwords():
    with open('passwords.json', 'w') as file:
        json.dump(passwords, file)

def save_emails():
    with open('emails.json', 'w') as file:
        json.dump(emails, file)

def check_pass(password):
    special_characters = string.punctuation
    has_digit = False
    has_lower = False
    has_special = False
    has_upper = False
    
    if len(password) < 8:
        print("Weak Password")
        return
    
    for char in password:
        if char.isupper():
            has_upper = True
        if char.islower():
            has_lower = True
        if char.isdigit():
            has_digit = True
        if char in special_characters:
            has_special = True

    if has_upper and has_lower and has_digit and has_special:
        print("Very Strong Password")
    elif has_upper and has_lower and has_digit:
        print("Strong Password")
    elif has_upper and has_lower and has_special:
        print("Moderately Strong Password")
    elif has_upper and has_lower:
        print("Moderate Password")
    else:
        print("Weak Password")


def generate_password(length=8, use_upper=True, use_lower=True, use_digits=True, use_special=True):
    characters = ''
    if use_upper:
        characters += string.ascii_uppercase
    if use_lower:
        characters += string.ascii_lowercase
    if use_digits:
        characters += string.digits
    if use_special:
        characters += string.punctuation
    if not characters:
        raise ValueError("At least one character set must be selected")
    return ''.join(secrets.choice(characters) for i in range(length))

def encrypt_password(password):
    encrypted_password = cipher_suite.encrypt(password.encode())
    return encrypted_password

def OTP_Generation(username, user_email):
    OTP = "".join([str(random.randint(0, 9)) for i in range(4)])
    server = smtplib.SMTP('smtp.gmail.com', 587)
    server.starttls()
    server.login("mhaskeshrikant01@gmail.com", "kmkf bzaf xstz xaof")
    subject = "Your OTP Code"
    body = f"Hello {username},\n\nYour OTP is: {OTP}\n\nRegards,\nPY07 Team"
    msg = f"Subject: {subject}\n\n{body}"
    server.sendmail("mhaskeshrikant01@gmail.com", user_email, msg)
    server.quit()
    return OTP

def create_account():
    username = input("Enter username: ")
    email = input("Enter email: ")
    pass_choice = input("Generate a password? (y/n): ")
    if pass_choice.lower() == "y":
        pass_length = int(input("Enter Length of Password (Minimum length should be 8): "))
        length = int(input("Enter password length: "))
        use_upper = input("Include uppercase letters? (y/n): ").lower() == 'y'
        use_lower = input("Include lowercase letters? (y/n): ").lower() == 'y'
        use_digits = input("Include digits? (y/n): ").lower() == 'y'
        use_special = input("Include special characters? (y/n): ").lower() == 'y'
        password = generate_password(pass_length, use_upper, use_lower, use_digits, use_special)
    else:
        password = getpass.getpass("Enter password: ")
        check_pass(password)
    hashed = bcrypt.hashpw(password.encode(), bcrypt.gensalt())
    users[username] = hashed
    encrypted_password = encrypt_password(password)
    passwords[username] = encrypted_password.decode()
    emails[username] = email
    save_users()
    save_passwords()
    save_emails()
    print("Account created successfully!")


def add_password(username):
    category = input("Enter category: ")
    if category not in passwords:
        passwords[category] = {}
    account = input("Enter account name: ")
    choice = input("Generate a password? (y/n): ")
    if choice.lower() == 'y':
        pass_length = int(input("Enter password length: "))
        use_upper = generate_password(pass_length)
    else:
        password = getpass.getpass("Password: ")
        check_pass(password)
    
    encrypted_password = cipher_suite.encrypt(password.encode()).decode()
    passwords[category][account] = encrypted_password
    save_passwords()
    print("Password added successfully!")


def retrieve_password(username):
    user_email = emails.get(username)
    if user_email:
        OTP = OTP_Generation(username, user_email)
        print("An OTP has been sent to your registered email address.")
        user_otp = input("OTP: ")
        if user_otp == OTP:
            category = input("Enter category: ")
            account = input("Enter account name: ")
            if category in passwords and account in passwords[category]:
                encrypted_password = passwords[category][account]
                decrypted_password = cipher_suite.decrypt(encrypted_password.encode()).decode()
                print(f"Password for {account}: {decrypted_password}")
            else:
                print("Account not found.")
        else:
            print("Invalid OTP")

def delete_password():
    category = input("Enter category: ")
    account = input("Enter account name: ")
    if category in passwords and account in passwords[category]:
        del passwords[category][account]
        if not passwords[category]:
            del passwords[category]
        save_passwords()
        print("Password deleted successfully.")
    else:
        print("Account not found.")

def list_passwords():
    for category, accounts in passwords.items():
        print(f"\nCategory: {category}")
        for account in accounts:
            print(f"  Account: {account}") 


def authenticate(username, password):
    if username in users and bcrypt.checkpw(password.encode(), users[username]):
        return True
    return False

def login():
    username = input("Username: ")
    password = getpass.getpass("Password: ")

    if authenticate(username, password):
        user_email = emails.get(username)
        if user_email:
            OTP = OTP_Generation(username, user_email)
            print("An OTP has been sent to your registered email address.")
            user_otp = input("OTP: ")
            if user_otp == OTP:
                print("Login Successfully")
                password_manager(username)
                return username
            else:
                print("Invalid OTP")
        else:
            print("Email not found for the user.")
    else:
        print("User Not Found!")
    return None

def password_manager(username):
    print("\nPassword Best Practices:")
    print("- Use a mix of uppercase and lowercase letters, numbers, and special characters.")
    print("- Avoid using easily guessable passwords like 'password' or '123456'.")
    print("- Regularly update your passwords to enhance security.")
    print("- Use different passwords for different accounts to minimize risk.\n")
    
    while True:
        print("\nPassword Manager - Main Menu")
        print("1. Add Password")
        print("2. Retrieve Password")
        print("3. Delete Password")
        print("4. List All Passwords")
        print("5. Logout")
        choice = input("Enter choice: ")
        if choice == '1':
            add_password(username)
        elif choice == '2':
            retrieve_password(username)
        elif choice == '3':
            delete_password()
        elif choice == '4':
            list_passwords()
        elif choice == '5':
            break
        else:
            print("Invalid choice, please try again.")


load_users()
load_passwords()
load_emails()

while True:
    print("\nPassword Manager")
    print("1. Login")
    print("2. Create Account")
    print("3. Exit")
    choice = input("Enter choice: ")
    if choice == '1':
        user = login()
    elif choice == '2':
        create_account()
    elif choice == '3':
        break
    else:
        print("Invalid choice, please try again.")
